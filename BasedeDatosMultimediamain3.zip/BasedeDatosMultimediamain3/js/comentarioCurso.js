var ComentarioCurso = function(valoracion, contenido) {
	this.valoracion = valoracion;
	this.contenido = contenido;
};