var Nivel = function(nombre, desc, video, archivo) {
	this.nombre = nombre;
	this.desc = desc;
	this.video = video;
	this.archivo = archivo;
};